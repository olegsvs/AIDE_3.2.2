package $package_name$;

import android.app.*;
import android.os.*;

public class WearableActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wearable);
    }
}
